'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const MAX_BODY = 8 * 1024;
const RATE_WINDOW_MS = 60_000;
const RATE_MAX = 20;

const products = [
  { id: 1, category: 'diamonds', name: 'باقة 100 جوهرة', description: 'باقة بداية بتصميم تجريبي أنيق.', price: 250, emoji: '💎', badge: 'الأكثر طلبًا', badgeType: 'hot', featured: 1 },
  { id: 2, category: 'diamonds', name: 'باقة 310 جواهر', description: 'خيار متوسط لعشاق الجواهر.', price: 650, emoji: '💠', badge: 'قيمة مميزة', badgeType: '', featured: 2 },
  { id: 3, category: 'diamonds', name: 'باقة 520 جوهرة', description: 'باقة كبيرة ضمن نموذج المتجر.', price: 990, emoji: '💎', badge: 'باقة كبيرة', badgeType: '', featured: 3 },
  { id: 4, category: 'codes', name: 'بطاقة كود مكافأة', description: 'عنصر توضيحي لعرض الأكواد الرقمية.', price: 180, emoji: '🎟️', badge: 'تجريبي', badgeType: '', featured: 4 },
  { id: 5, category: 'codes', name: 'صندوق المفاجآت', description: 'بطاقة عرض تجريبية بتصميم مميز.', price: 320, emoji: '🎁', badge: 'مميز', badgeType: 'hot', featured: 5 },
  { id: 6, category: 'skins', name: 'سكن النيون الأزرق', description: 'تصميم رمزي لفئة السكنات النادرة.', price: 1200, emoji: '🧥', badge: 'نادر', badgeType: 'rare', featured: 6 },
  { id: 7, category: 'skins', name: 'حزمة المحارب', description: 'عرض بصري تجريبي لعشاق المظاهر.', price: 850, emoji: '🛡️', badge: 'مميز', badgeType: '', featured: 7 },
  { id: 8, category: 'emotes', name: 'رقصة الاحتفال', description: 'عنصر توضيحي لفئة الرقصات.', price: 450, emoji: '🕺', badge: 'جديد', badgeType: '', featured: 8 }
];

// In-memory demo receipts only. No player IDs, passwords or payment details are retained.
const demoOrders = [];
const rateLog = new Map();
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon'
};

function sendJson(res, status, payload) {
  const data = JSON.stringify(payload);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(data), 'Cache-Control': 'no-store' });
  res.end(data);
}
function rateLimited(req) {
  const key = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const current = rateLog.get(key);
  if (!current || now - current.start >= RATE_WINDOW_MS) {
    rateLog.set(key, { start: now, count: 1 });
    return false;
  }
  current.count += 1;
  return current.count > RATE_MAX;
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    let tooLarge = false;
    req.on('data', chunk => {
      if (tooLarge) return;
      body += chunk;
      if (Buffer.byteLength(body) > MAX_BODY) { tooLarge = true; body = ''; }
    });
    req.on('end', () => {
      if (tooLarge) return reject(Object.assign(new Error('حجم الطلب كبير جدًا.'), { statusCode: 413 }));
      try { resolve(JSON.parse(body || '{}')); }
      catch { reject(Object.assign(new Error('صيغة بيانات الطلب غير صحيحة.'), { statusCode: 400 })); }
    });
    req.on('error', reject);
  });
}
function normalizeItems(input) {
  if (!Array.isArray(input) || input.length < 1 || input.length > 10) throw Object.assign(new Error('اختر من عنصر واحد إلى 10 عناصر مختلفة.'), { statusCode: 400 });
  const merged = new Map();
  for (const item of input) {
    const id = Number(item?.productId);
    const quantity = Number(item?.quantity);
    if (!Number.isSafeInteger(id) || !Number.isSafeInteger(quantity) || quantity < 1 || quantity > 20) {
      throw Object.assign(new Error('بيانات المنتج أو الكمية غير صالحة.'), { statusCode: 400 });
    }
    if (!products.some(p => p.id === id)) throw Object.assign(new Error('أحد المنتجات غير معروف.'), { statusCode: 400 });
    merged.set(id, (merged.get(id) || 0) + quantity);
  }
  const items = [...merged.entries()].map(([id, quantity]) => {
    const p = products.find(product => product.id === id);
    return { productId: id, name: p.name, unitPrice: p.price, quantity, lineTotal: p.price * quantity };
  });
  const total = items.reduce((sum, item) => sum + item.lineTotal, 0);
  if (!Number.isSafeInteger(total) || total < 1) throw Object.assign(new Error('تعذر حساب المجموع.'), { statusCode: 400 });
  return { items, total, count: items.reduce((sum, item) => sum + item.quantity, 0) };
}
async function handleApi(req, res, url) {
  if (url.pathname === '/api/health' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, mode: 'demo-only', paymentEnabled: false, fulfillmentEnabled: false });
  }
  if (url.pathname === '/api/products' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, currency: 'DZD', products });
  }
  if (url.pathname === '/api/orders' && req.method === 'POST') {
    if (rateLimited(req)) return sendJson(res, 429, { ok: false, error: 'طلبات كثيرة خلال وقت قصير. حاول لاحقًا.' });
    const contentType = String(req.headers['content-type'] || '').toLowerCase();
    if (!contentType.includes('application/json')) return sendJson(res, 415, { ok: false, error: 'يجب إرسال الطلب بصيغة JSON.' });
    try {
      const payload = await readJson(req);
      if (typeof payload.playerId !== 'string' || !/^[0-9]{6,16}$/.test(payload.playerId.trim())) {
        return sendJson(res, 400, { ok: false, error: 'معرّف اللاعب يجب أن يتكون من 6 إلى 16 رقمًا.' });
      }
      const normalized = normalizeItems(payload.items);
      const order = {
        reference: crypto.randomBytes(4).toString('hex').toUpperCase(),
        createdAt: new Date().toISOString(), status: 'DEMO_ONLY_NOT_FULFILLED',
        items: normalized.items, total: normalized.total, itemCount: normalized.count
      };
      // Deliberately do not retain playerId. The in-memory receipt disappears when the server stops.
      demoOrders.unshift(order);
      if (demoOrders.length > 100) demoOrders.length = 100;
      return sendJson(res, 201, { ok: true, order, note: 'طلب تجريبي فقط: لا دفع ولا شحن.' });
    } catch (error) {
      return sendJson(res, error.statusCode || 400, { ok: false, error: error.message || 'تعذر إنشاء الطلب التجريبي.' });
    }
  }
  return sendJson(res, 404, { ok: false, error: 'المسار غير موجود.' });
}
function serveStatic(req, res, url) {
  let decoded;
  try { decoded = decodeURIComponent(url.pathname); }
  catch { res.writeHead(400); return res.end('Bad Request'); }
  const requested = decoded === '/' ? '/index.html' : decoded;
  const target = path.resolve(ROOT, '.' + requested);
  const relative = path.relative(ROOT, target);
  if (relative.startsWith('..') || path.isAbsolute(relative)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(target, (statError, stat) => {
    if (statError || !stat.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Not Found'); }
    const ext = path.extname(target).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': stat.size, 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300' });
    fs.createReadStream(target).pipe(res);
  });
}
const server = http.createServer((req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
  let url;
  try { url = new URL(req.url, `http://${req.headers.host || 'localhost'}`); }
  catch { res.writeHead(400); return res.end('Bad Request'); }
  if (url.pathname.startsWith('/api/')) {
    handleApi(req, res, url).catch(() => { if (!res.headersSent) sendJson(res, 500, { ok: false, error: 'حدث خطأ داخلي.' }); });
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }); return res.end('Method Not Allowed'); }
  if (req.method === 'HEAD') {
    const target = path.resolve(ROOT, '.' + (url.pathname === '/' ? '/index.html' : url.pathname));
    const relative = path.relative(ROOT, target);
    if (relative.startsWith('..') || path.isAbsolute(relative)) { res.writeHead(403); return res.end(); }
    return fs.stat(target, (err, stat) => { if (err || !stat.isFile()) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'Content-Type': MIME[path.extname(target)] || 'application/octet-stream', 'Content-Length': stat.size }); res.end(); });
  }
  serveStatic(req, res, url);
});
server.listen(PORT, '0.0.0.0', () => console.log(`BlueDrop demo server running at http://localhost:${PORT}`));
